// index.js
// Lambda函数入口点，符合默认处理程序配置

// 导入主要实现文件
const { handler } = require('./la-hourly-sync');

// 导出处理函数使其与默认配置兼容
exports.handler = async (event, context) => {
  console.log('通过索引文件调用处理程序...');
  return await handler(event, context);
}; 