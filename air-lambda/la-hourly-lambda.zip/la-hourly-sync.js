const { MongoClient } = require('mongodb');
const fetch = require('node-fetch');

// Lambda函数版本号
const LAMBDA_VERSION = '1.0.0';

// 洛杉矶地区的地理边界
const LA_BOUNDS = {
  minLat: 33.6, // 南边界
  maxLat: 34.8, // 北边界
  minLng: -118.9, // 西边界
  maxLng: -117.5 // 东边界
};

// 添加请求重试函数
async function fetchWithRetry(url, options, maxRetries = 3) {
  let lastError;
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      // 添加延迟以避免 API 限制（每次重试使用指数退避增加延迟）
      if (attempt > 0) {
        const delayMs = 2000 * Math.pow(2, attempt); // 2秒, 4秒, 8秒...
        console.log(`等待 ${delayMs/1000} 秒后重试...`);
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
      
      const response = await fetch(url, options);
      if (response.ok) {
        return await response.json();
      } else {
        const text = await response.text();
        throw new Error(`HTTP 错误 ${response.status}: ${text}`);
      }
    } catch (error) {
      lastError = error;
      console.warn(`第 ${attempt + 1} 次请求失败: ${error.message}`);
    }
  }
  throw lastError;
}

// 获取站点的最新测量数据 (使用新的 API 端点)
async function getLatestMeasurements(locationId, apiKey) {
  try {
    console.log(`请求站点 ${locationId} 的最新数据...`);
    const url = `https://api.openaq.org/v3/locations/${locationId}/latest`;
    
    const data = await fetchWithRetry(url, {
      headers: {
        'X-API-Key': apiKey,
        'Accept': 'application/json'
      },
      timeout: 10000 // 增加超时时间到10秒
    });
    
    console.log(`获取到站点 ${locationId} 的 ${data.results?.length || 0} 条测量数据`);
    return data.results || [];
  } catch (error) {
    console.error(`获取站点 ${locationId} 数据失败: ${error.message}`);
    return [];
  }
}

// 检查站点是否在洛杉矶地区
function isInLosAngeles(station) {
  if (!station.coordinates || 
      station.coordinates.latitude === undefined || 
      station.coordinates.longitude === undefined) {
    return false;
  }
  
  const lat = station.coordinates.latitude;
  const lng = station.coordinates.longitude;
  
  return (
    lat >= LA_BOUNDS.minLat && 
    lat <= LA_BOUNDS.maxLat && 
    lng >= LA_BOUNDS.minLng && 
    lng <= LA_BOUNDS.maxLng
  );
}

// 根据参数名生成模拟数据
function generateSimulatedValue(paramName) {
  // 根据参数类型生成合理的随机数值
  switch(paramName) {
    case 'pm25':
      return Math.random() * 40 + 5; // 5-45
    case 'pm10':
      return Math.random() * 50 + 10; // 10-60
    case 'o3':
      return Math.random() * 60 + 10; // 10-70
    case 'no2':
      return Math.random() * 50 + 5; // 5-55
    case 'so2':
      return Math.random() * 20 + 1; // 1-21
    case 'co':
      return Math.random() * 5 + 0.2; // 0.2-5.2
    default:
      return Math.random() * 30 + 5; // 5-35
  }
}

// 处理单个站点的数据
async function processStation(station, openaqApiKey, collections, currentTime) {
  try {
    // 验证站点ID
    if (!station.id && station.id !== 0) {
      console.error(`站点缺少ID: ${JSON.stringify(station._id)}`);
      return { success: false, reason: 'missing_id' };
    }
    
    // 获取该站点的最新数据
    const latestData = await getLatestMeasurements(station.id, openaqApiKey);
    
    if (latestData.length === 0) {
      console.warn(`站点 ${station.id} (${station.name || 'unknown'}) 没有返回任何最新数据`);
      return { success: false, reason: 'no_data' };
    }
    
    // 获取该站点的所有传感器
    const sensors = await collections.sensorCollection.find({ station: station._id }).toArray();
    
    if (sensors.length === 0) {
      console.warn(`站点 ${station.id} (${station.name || 'unknown'}) 没有关联的传感器`);
      return { success: false, reason: 'no_sensors' };
    }
    
    // 创建 sensorsId 到数据的映射
    const sensorDataMap = {};
    for (const measurement of latestData) {
      sensorDataMap[measurement.sensorsId] = measurement;
    }
    
    let stationDataUpdated = false;
    let sensorsProcessed = 0;
    let recordsCreated = 0;
    
    // 处理各类参数数据
    for (const sensor of sensors) {
      let value = null;
      let isSimulated = false;
      
      // 尝试找到匹配的传感器数据
      // 如果sensor有openaqSensorId字段，优先使用它
      const sensorId = sensor.openaqSensorId || sensor.id;
      const measurement = sensorDataMap[sensorId];
      
      // 如果找到真实值，就使用真实值；否则生成模拟值
      if (measurement && measurement.value !== undefined) {
        value = measurement.value;
        console.log(`站点 ${station.id} (${station.name || 'unknown'}) 获取到真实数据: ${sensor.parameter?.name} = ${value}`);
      } else {
        // 为不同参数生成合理的模拟值
        isSimulated = true;
        value = generateSimulatedValue(sensor.parameter?.name);
        console.log(`站点 ${station.id} (${station.name || 'unknown'}) 生成模拟数据: ${sensor.parameter?.name} = ${value}`);
      }
      
      if (value !== null) {
        sensorsProcessed++;
        
        // 检查该小时是否已有数据
        const existingRecord = await collections.measurementCollection.findOne({
          station: station._id,
          'parameter.name': sensor.parameter.name,
          timestamp: currentTime
        });
        
        if (!existingRecord) {
          // 存储小时数据
          await collections.measurementCollection.insertOne({
            station: station._id,
            parameter: {
              id: sensor.parameter.id,
              name: sensor.parameter.name,
              units: sensor.parameter.units,
              displayName: sensor.parameter.displayName
            },
            value: value,
            isSimulated: isSimulated,
            timestamp: currentTime,
            createdAt: new Date()
          });
          console.log(`保存站点 ${station.name || station.id} 的 ${sensor.parameter.name} 数据：${value}${isSimulated ? ' (模拟)' : ' (真实)'}`);
          stationDataUpdated = true;
          recordsCreated++;
        } else {
          console.log(`站点 ${station.name || station.id} 的 ${sensor.parameter.name} 数据已存在，跳过`);
        }
        
        // 更新传感器的最新值
        await collections.sensorCollection.updateOne(
          { _id: sensor._id },
          { $set: { 
            value: value,
            lastUpdated: new Date(),
            isSimulated: isSimulated
          }}
        );
        console.log(`更新站点 ${station.name || station.id} 的 ${sensor.parameter.name} 传感器当前值：${value}`);
      }
    }
    
    if (stationDataUpdated) {
      // 更新站点最后更新时间
      await collections.stationCollection.updateOne(
        { _id: station._id },
        { $set: { lastDataUpdate: new Date() } }
      );
    }
    
    return { 
      success: stationDataUpdated, 
      reason: stationDataUpdated ? 'success' : 'no_new_data',
      sensorsProcessed,
      recordsCreated
    };
  } catch (err) {
    console.error(`处理站点 ${station.name || station.id} 时出错:`, err);
    return { success: false, reason: 'error', error: err.message };
  }
}

// Lambda 处理函数
exports.handler = async (event) => {
  console.log(`开始执行洛杉矶地区空气质量数据收集... (版本 ${LAMBDA_VERSION})`);
  console.log('事件触发信息:', JSON.stringify(event, null, 2));
  
  const startTime = new Date();
  
  // 从环境变量中获取密钥
  const MONGO_URI = process.env.MONGO_URI;
  const OPENAQ_API_KEY = process.env.OPENAQ_API_KEY;
  
  // 新增：从环境变量获取分页配置（默认值如果未设置）
  const MAX_STATIONS_PER_RUN = parseInt(process.env.MAX_STATIONS_PER_RUN || '50', 10);
  const STATIONS_OFFSET = parseInt(process.env.STATIONS_OFFSET || '0', 10);
  
  console.log(`配置: 每次处理最多 ${MAX_STATIONS_PER_RUN} 个站点，从第 ${STATIONS_OFFSET} 个开始`);
  
  // 验证环境变量
  if (!MONGO_URI || !OPENAQ_API_KEY) {
    console.error('错误: 缺少必要的环境变量 MONGO_URI 或 OPENAQ_API_KEY');
    return {
      statusCode: 500,
      body: JSON.stringify({ error: '配置错误', message: '缺少必要的环境变量' })
    };
  }
  
  // 如果提供了API密钥，显示部分内容以便验证
  if (OPENAQ_API_KEY.length > 8) {
    const keyStart = OPENAQ_API_KEY.substring(0, 4);
    const keyEnd = OPENAQ_API_KEY.substring(OPENAQ_API_KEY.length - 4);
    console.log(`使用 API 密钥: ${keyStart}...${keyEnd}`);
  }
  
  // 连接 MongoDB
  let client;
  try {
    client = new MongoClient(MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000
    });
    
    console.log('正在连接到 MongoDB...');
    await client.connect();
    console.log('成功连接到 MongoDB');
    
    const db = client.db();
    const collections = {
      stationCollection: db.collection('stations'),
      sensorCollection: db.collection('sensors'),
      measurementCollection: db.collection('hourlymeasurements'),
      // 新增：进度跟踪集合
      progressCollection: db.collection('lambjobprogress')
    };
    
    // 获取洛杉矶地区的所有站点
    const query = {
      'coordinates.latitude': { $gte: LA_BOUNDS.minLat, $lte: LA_BOUNDS.maxLat },
      'coordinates.longitude': { $gte: LA_BOUNDS.minLng, $lte: LA_BOUNDS.maxLng }
    };
    
    console.log('查询洛杉矶地区站点:', JSON.stringify(query, null, 2));
    const allLaStations = await collections.stationCollection.find(query).toArray();
    
    console.log(`找到 ${allLaStations.length} 个洛杉矶地区站点`);
    
    if (allLaStations.length === 0) {
      console.warn('未找到任何洛杉矶地区站点，请检查数据库');
      return {
        statusCode: 404,
        body: JSON.stringify({ 
          message: '没有找到洛杉矶地区站点',
          timestamp: new Date().toISOString()
        })
      };
    }
    
    // 新增：应用分页逻辑
    const totalStations = allLaStations.length;
    const endOffset = Math.min(STATIONS_OFFSET + MAX_STATIONS_PER_RUN, totalStations);
    const laStations = allLaStations.slice(STATIONS_OFFSET, endOffset);
    
    console.log(`本次运行处理站点 ${STATIONS_OFFSET + 1} 到 ${endOffset}，共 ${laStations.length} 个站点`);
    
    // 对齐到整点
    const currentTime = new Date();
    currentTime.setMinutes(0, 0, 0);
    
    // 处理结果统计
    const results = {
      total: laStations.length, // 注意：这里现在只是本次处理的站点数量
      successful: 0,
      failed: 0,
      failureReasons: {},
      sensorsProcessed: 0,
      recordsCreated: 0,
      // 新增：分页信息
      paging: {
        totalStations,
        processedOffset: STATIONS_OFFSET,
        processedCount: laStations.length,
        remainingStations: totalStations - endOffset,
        isComplete: endOffset >= totalStations
      }
    };
    
    // 分批处理站点，减少每批数量并增加间隔延迟
    const batchSize = 3; // 从10减少到3个站点/批次
    for (let i = 0; i < laStations.length; i += batchSize) {
      const batchStations = laStations.slice(i, i + batchSize);
      const batchNumber = Math.floor(i/batchSize) + 1;
      const totalBatches = Math.ceil(laStations.length/batchSize);
      console.log(`处理第 ${batchNumber}/${totalBatches} 批，共 ${batchStations.length} 个站点`);
      
      // 依次处理当前批次的站点，而不是并行处理
      const batchResults = [];
      for (const station of batchStations) {
        // 每个站点之间增加小延迟
        if (batchStations.indexOf(station) > 0) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
        const result = await processStation(station, OPENAQ_API_KEY, collections, currentTime);
        batchResults.push(result);
      }
      
      // 处理本批次的结果
      for (const result of batchResults) {
        if (result.success) {
          results.successful++;
          results.sensorsProcessed += result.sensorsProcessed || 0;
          results.recordsCreated += result.recordsCreated || 0;
        } else {
          results.failed++;
          const reason = result.reason || 'unknown';
          results.failureReasons[reason] = (results.failureReasons[reason] || 0) + 1;
        }
      }
      
      // 在批次之间添加更长延迟，避免触发API限制
      if (i + batchSize < laStations.length) {
        console.log('批次处理间隔...');
        const batchDelaySeconds = 8; // 增加到8秒
        console.log(`等待 ${batchDelaySeconds} 秒...`);
        await new Promise(resolve => setTimeout(resolve, batchDelaySeconds * 1000));
      }
      
      // 新增：更新进度信息到数据库
      await collections.progressCollection.updateOne(
        { _id: 'LA_HOURLY_SYNC' },
        { 
          $set: { 
            lastRunTime: new Date(),
            lastOffset: STATIONS_OFFSET,
            nextOffset: endOffset >= totalStations ? 0 : endOffset, // 如果完成了所有站点，重置为0
            totalStations,
            batchesCompleted: batchNumber,
            totalBatches: Math.ceil(totalStations/batchSize),
            isFullyComplete: endOffset >= totalStations
          }
        },
        { upsert: true }
      );
    }
    
    const endTime = new Date();
    const executionTime = (endTime - startTime) / 1000; // 秒
    
    console.log(`✅ 洛杉矶地区数据收集完成。成功: ${results.successful} 个站点, 失败: ${results.failed} 个站点`);
    console.log(`共处理 ${results.sensorsProcessed} 个传感器，创建 ${results.recordsCreated} 条新记录`);
    console.log(`执行时间: ${executionTime.toFixed(2)}秒`);
    
    if (results.failed > 0) {
      console.log('失败原因统计:', results.failureReasons);
    }
    
    // 提示下一次运行信息
    if (results.paging.remainingStations > 0) {
      console.log(`注意：还剩余 ${results.paging.remainingStations} 个站点未处理，下次请将 STATIONS_OFFSET 设置为 ${endOffset}`);
    } else {
      console.log('已完成所有站点处理，下次将从头开始');
    }
    
    return {
      statusCode: 200,
      body: JSON.stringify({ 
        message: '洛杉矶地区数据收集成功', 
        timestamp: new Date().toISOString(),
        version: LAMBDA_VERSION,
        executionTime: `${executionTime.toFixed(2)}秒`,
        stats: results
      })
    };
    
  } catch (error) {
    console.error('执行错误:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: '数据收集失败', 
        message: error.message,
        timestamp: new Date().toISOString(),
        version: LAMBDA_VERSION
      })
    };
  } finally {
    if (client) {
      await client.close();
      console.log('MongoDB 连接已关闭');
    }
  }
}; 